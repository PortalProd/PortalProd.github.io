const basketballTransfers = [
  {
    "playerId": "46165688",
    "name": "A'lahn Sumler",
    "sport": "basketball",
    "position": "CG",
    "previousSchool": "Charleston Southern",
    "destination": "Pittsburgh",
    "season": 2026,
    "profileUrl": "basketball-profile-46165688.html",
    "stats": {
      "minutesPerGame": 30.3,
      "pointsPerGame": 18.9,
      "reboundsPerGame": 4.8,
      "assistsPerGame": 3.8,
      "stealsPerGame": 0.8,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 48.0,
      "threePointPercentage": 39.6,
      "freeThrowPercentage": 65.4
    },
    "transferHistory": [
      {
        "recordId": "3447",
        "previousSchool": "Charleston Southern",
        "destination": "Pittsburgh",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46055704",
    "name": "A.J. Neal Jr.",
    "sport": "basketball",
    "position": "CG",
    "previousSchool": "Long Island University",
    "destination": "",
    "season": 2026,
    "profileUrl": "basketball-profile-46055704.html",
    "stats": {
      "minutesPerGame": 7.7,
      "pointsPerGame": 1.9,
      "reboundsPerGame": 0.4,
      "assistsPerGame": 0.7,
      "stealsPerGame": 0.3,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 43.5,
      "threePointPercentage": 50.0,
      "freeThrowPercentage": 66.7
    },
    "transferHistory": [
      {
        "recordId": "86922",
        "previousSchool": "Long Island University",
        "destination": "",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46103528",
    "name": "Aaron Bradshaw",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Memphis",
    "destination": "Tennessee State",
    "season": 2026,
    "profileUrl": "basketball-profile-46103528.html",
    "stats": {
      "minutesPerGame": 18.9,
      "pointsPerGame": 8.6,
      "reboundsPerGame": 4.2,
      "assistsPerGame": 0.6,
      "stealsPerGame": 0.5,
      "blocksPerGame": 0.6,
      "fieldGoalPercentage": 53.6,
      "threePointPercentage": 33.3,
      "freeThrowPercentage": 77.2
    },
    "transferHistory": [
      {
        "recordId": "288129",
        "previousSchool": "Memphis",
        "destination": "Tennessee State",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46110312",
    "name": "Aaron Clark",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Pepperdine",
    "destination": "Little Rock",
    "season": 2026,
    "profileUrl": "basketball-profile-46110312.html",
    "stats": {
      "minutesPerGame": 32.3,
      "pointsPerGame": 15.3,
      "reboundsPerGame": 3.4,
      "assistsPerGame": 2.7,
      "stealsPerGame": 1.2,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 42.3,
      "threePointPercentage": 36.1,
      "freeThrowPercentage": 76.9
    },
    "transferHistory": [
      {
        "recordId": "2681",
        "previousSchool": "Pepperdine",
        "destination": "Little Rock",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46117797",
    "name": "Aaron Powell",
    "sport": "basketball",
    "position": "PG",
    "previousSchool": "Rice",
    "destination": "Weber State",
    "season": 2026,
    "profileUrl": "basketball-profile-46117797.html",
    "stats": {
      "minutesPerGame": 6.5,
      "pointsPerGame": 2.4,
      "reboundsPerGame": 0.5,
      "assistsPerGame": 0.2,
      "stealsPerGame": 0.2,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 32.8,
      "threePointPercentage": 30.4,
      "freeThrowPercentage": 78.9
    },
    "transferHistory": [
      {
        "recordId": "3079",
        "previousSchool": "Rice",
        "destination": "Weber State",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46152757",
    "name": "Aaron Womack II",
    "sport": "basketball",
    "position": "SF",
    "previousSchool": "Syracuse",
    "destination": "Milwaukee",
    "season": 2026,
    "profileUrl": "basketball-profile-46152757.html",
    "stats": {},
    "transferHistory": [
      {
        "recordId": "2769",
        "previousSchool": "Syracuse",
        "destination": "Milwaukee",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46153674",
    "name": "Abdi Bashir Jr.",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Kansas State",
    "destination": "LSU",
    "season": 2026,
    "profileUrl": "basketball-profile-46153674.html",
    "stats": {
      "minutesPerGame": 24.7,
      "pointsPerGame": 13.2,
      "reboundsPerGame": 2.2,
      "assistsPerGame": 2.3,
      "stealsPerGame": 0.5,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 42.1,
      "threePointPercentage": 44.4,
      "freeThrowPercentage": 68.8
    },
    "transferHistory": [
      {
        "recordId": "2749",
        "previousSchool": "Kansas State",
        "destination": "LSU",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46152212",
    "name": "Abdul Bashir",
    "sport": "basketball",
    "position": "SF",
    "previousSchool": "Auburn",
    "destination": "San Francisco",
    "season": 2026,
    "profileUrl": "basketball-profile-46152212.html",
    "stats": {
      "minutesPerGame": 8.8,
      "pointsPerGame": 2.0,
      "reboundsPerGame": 0.5,
      "assistsPerGame": 0.5,
      "stealsPerGame": 0.2,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 26.7,
      "threePointPercentage": 15.4,
      "freeThrowPercentage": 100.0
    },
    "transferHistory": [
      {
        "recordId": "27517",
        "previousSchool": "Auburn",
        "destination": "San Francisco",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46162404",
    "name": "Abdullah Ahmed",
    "sport": "basketball",
    "position": "C",
    "previousSchool": "BYU",
    "destination": "Massachusetts",
    "season": 2026,
    "profileUrl": "basketball-profile-46162404.html",
    "stats": {
      "minutesPerGame": 12.2,
      "pointsPerGame": 1.3,
      "reboundsPerGame": 2.7,
      "assistsPerGame": 0.4,
      "stealsPerGame": 0.1,
      "blocksPerGame": 1.4,
      "fieldGoalPercentage": 50.0,
      "threePointPercentage": 0.0,
      "freeThrowPercentage": 41.7
    },
    "transferHistory": [
      {
        "recordId": "60252",
        "previousSchool": "BYU",
        "destination": "Massachusetts",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46148867",
    "name": "Abou Magassa",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Wyoming",
    "destination": "UNC Asheville",
    "season": 2026,
    "profileUrl": "basketball-profile-46148867.html",
    "stats": {
      "minutesPerGame": 10.3,
      "pointsPerGame": 3.1,
      "reboundsPerGame": 3.0,
      "assistsPerGame": 0.2,
      "stealsPerGame": 0.3,
      "blocksPerGame": 0.2,
      "fieldGoalPercentage": 57.6,
      "threePointPercentage": 0.0,
      "freeThrowPercentage": 51.2
    },
    "transferHistory": [
      {
        "recordId": "2646",
        "previousSchool": "Wyoming",
        "destination": "UNC Asheville",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46135497",
    "name": "Abraham Oyeadier",
    "sport": "basketball",
    "position": "C",
    "previousSchool": "West Virginia",
    "destination": "UC Riverside",
    "season": 2026,
    "profileUrl": "basketball-profile-46135497.html",
    "stats": {
      "minutesPerGame": 2.0,
      "pointsPerGame": 0.0,
      "reboundsPerGame": 2.0,
      "assistsPerGame": 0.0,
      "stealsPerGame": 0.0,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 0.0,
      "threePointPercentage": 0.0,
      "freeThrowPercentage": 0.0
    },
    "transferHistory": [
      {
        "recordId": "83135",
        "previousSchool": "West Virginia",
        "destination": "UC Riverside",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46141102",
    "name": "Abu Yarmah",
    "sport": "basketball",
    "position": "SF",
    "previousSchool": "South Carolina",
    "destination": "Longwood",
    "season": 2026,
    "profileUrl": "basketball-profile-46141102.html",
    "stats": {},
    "transferHistory": [
      {
        "recordId": "8605",
        "previousSchool": "South Carolina",
        "destination": "Longwood",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166532",
    "name": "AC Bryant",
    "sport": "basketball",
    "position": "CG",
    "previousSchool": "Jacksonville State",
    "destination": "",
    "season": 2026,
    "profileUrl": "basketball-profile-46166532.html",
    "stats": {
      "minutesPerGame": 27.7,
      "pointsPerGame": 11.8,
      "reboundsPerGame": 3.9,
      "assistsPerGame": 0.9,
      "stealsPerGame": 1.1,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 39.7,
      "threePointPercentage": 39.1,
      "freeThrowPercentage": 68.5
    },
    "transferHistory": [
      {
        "recordId": "380631",
        "previousSchool": "Jacksonville State",
        "destination": "",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46141946",
    "name": "Acaden Lewis",
    "sport": "basketball",
    "position": "CG",
    "previousSchool": "Villanova",
    "destination": "Miami",
    "season": 2026,
    "profileUrl": "basketball-profile-46141946.html",
    "stats": {
      "minutesPerGame": 30.5,
      "pointsPerGame": 12.2,
      "reboundsPerGame": 3.0,
      "assistsPerGame": 5.3,
      "stealsPerGame": 1.9,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 45.6,
      "threePointPercentage": 27.0,
      "freeThrowPercentage": 58.3
    },
    "transferHistory": [
      {
        "recordId": "2963",
        "previousSchool": "Villanova",
        "destination": "Miami",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46136620",
    "name": "Ace Glass",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Washington State",
    "destination": "Vanderbilt",
    "season": 2026,
    "profileUrl": "basketball-profile-46136620.html",
    "stats": {
      "minutesPerGame": 28.8,
      "pointsPerGame": 16.4,
      "reboundsPerGame": 3.0,
      "assistsPerGame": 2.3,
      "stealsPerGame": 0.8,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 45.5,
      "threePointPercentage": 36.4,
      "freeThrowPercentage": 88.2
    },
    "transferHistory": [
      {
        "recordId": "3001",
        "previousSchool": "Washington State",
        "destination": "Vanderbilt",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166173",
    "name": "Ace Valentine",
    "sport": "basketball",
    "position": "CG",
    "previousSchool": "UMBC",
    "destination": "Robert Morris",
    "season": 2026,
    "profileUrl": "basketball-profile-46166173.html",
    "stats": {
      "minutesPerGame": 32.6,
      "pointsPerGame": 11.9,
      "reboundsPerGame": 4.1,
      "assistsPerGame": 3.9,
      "stealsPerGame": 0.8,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 50.6,
      "threePointPercentage": 38.1,
      "freeThrowPercentage": 77.0
    },
    "transferHistory": [
      {
        "recordId": "2499",
        "previousSchool": "UMBC",
        "destination": "Robert Morris",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46149405",
    "name": "Achor Achor",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Mississippi State",
    "destination": "",
    "season": 2026,
    "profileUrl": "basketball-profile-46149405.html",
    "stats": {
      "minutesPerGame": 17.8,
      "pointsPerGame": 6.2,
      "reboundsPerGame": 6.3,
      "assistsPerGame": 0.4,
      "stealsPerGame": 0.5,
      "blocksPerGame": 0.6,
      "fieldGoalPercentage": 42.7,
      "threePointPercentage": 28.6,
      "freeThrowPercentage": 69.6
    },
    "transferHistory": [
      {
        "recordId": "2466",
        "previousSchool": "Mississippi State",
        "destination": "",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46156285",
    "name": "Adam Clark",
    "sport": "basketball",
    "position": "PG",
    "previousSchool": "Seton Hall",
    "destination": "Ole Miss",
    "season": 2026,
    "profileUrl": "basketball-profile-46156285.html",
    "stats": {
      "minutesPerGame": 30.6,
      "pointsPerGame": 12.7,
      "reboundsPerGame": 3.0,
      "assistsPerGame": 4.9,
      "stealsPerGame": 2.0,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 43.7,
      "threePointPercentage": 22.0,
      "freeThrowPercentage": 74.6
    },
    "transferHistory": [
      {
        "recordId": "2465",
        "previousSchool": "Seton Hall",
        "destination": "Ole Miss",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166026",
    "name": "Adam Harakow",
    "sport": "basketball",
    "position": "SF",
    "previousSchool": "Wyoming",
    "destination": "Western Michigan",
    "season": 2026,
    "profileUrl": "basketball-profile-46166026.html",
    "stats": {
      "minutesPerGame": 18.9,
      "pointsPerGame": 6.1,
      "reboundsPerGame": 2.8,
      "assistsPerGame": 0.7,
      "stealsPerGame": 0.5,
      "blocksPerGame": 0.2,
      "fieldGoalPercentage": 46.3,
      "threePointPercentage": 38.1,
      "freeThrowPercentage": 68.0
    },
    "transferHistory": [
      {
        "recordId": "3068",
        "previousSchool": "Wyoming",
        "destination": "Western Michigan",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46157817",
    "name": "Adam Olsen",
    "sport": "basketball",
    "position": "SF",
    "previousSchool": "South Alabama",
    "destination": "Auburn",
    "season": 2026,
    "profileUrl": "basketball-profile-46157817.html",
    "stats": {
      "minutesPerGame": 35.8,
      "pointsPerGame": 16.7,
      "reboundsPerGame": 4.1,
      "assistsPerGame": 0.9,
      "stealsPerGame": 1.0,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 39.9,
      "threePointPercentage": 39.5,
      "freeThrowPercentage": 84.3
    },
    "transferHistory": [
      {
        "recordId": "3316",
        "previousSchool": "South Alabama",
        "destination": "Auburn",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46099972",
    "name": "Adante' Holiman",
    "sport": "basketball",
    "position": "PG",
    "previousSchool": "Arizona State",
    "destination": "Old Dominion",
    "season": 2026,
    "profileUrl": "basketball-profile-46099972.html",
    "stats": {},
    "transferHistory": [
      {
        "recordId": "3171",
        "previousSchool": "Arizona State",
        "destination": "Old Dominion",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166159",
    "name": "Ade Popoola",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Tulsa",
    "destination": "DePaul",
    "season": 2026,
    "profileUrl": "basketball-profile-46166159.html",
    "stats": {
      "minutesPerGame": 28.7,
      "pointsPerGame": 10.8,
      "reboundsPerGame": 4.2,
      "assistsPerGame": 1.3,
      "stealsPerGame": 1.3,
      "blocksPerGame": 0.3,
      "fieldGoalPercentage": 41.4,
      "threePointPercentage": 40.9,
      "freeThrowPercentage": 77.8
    },
    "transferHistory": [
      {
        "recordId": "2530",
        "previousSchool": "Tulsa",
        "destination": "DePaul",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46142622",
    "name": "Adlan Elamin",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Utah State",
    "destination": "Cincinnati",
    "season": 2026,
    "profileUrl": "basketball-profile-46142622.html",
    "stats": {
      "minutesPerGame": 19.5,
      "pointsPerGame": 6.7,
      "reboundsPerGame": 3.1,
      "assistsPerGame": 0.9,
      "stealsPerGame": 0.7,
      "blocksPerGame": 0.5,
      "fieldGoalPercentage": 44.4,
      "threePointPercentage": 30.2,
      "freeThrowPercentage": 83.0
    },
    "transferHistory": [
      {
        "recordId": "2819",
        "previousSchool": "Utah State",
        "destination": "Cincinnati",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46136692",
    "name": "Adrian Myers",
    "sport": "basketball",
    "position": "SF",
    "previousSchool": "San José State",
    "destination": "James Madison",
    "season": 2026,
    "profileUrl": "basketball-profile-46136692.html",
    "stats": {
      "minutesPerGame": 28.4,
      "pointsPerGame": 11.1,
      "reboundsPerGame": 4.9,
      "assistsPerGame": 1.0,
      "stealsPerGame": 1.0,
      "blocksPerGame": 0.8,
      "fieldGoalPercentage": 42.9,
      "threePointPercentage": 37.2,
      "freeThrowPercentage": 72.7
    },
    "transferHistory": [
      {
        "recordId": "3376",
        "previousSchool": "San José State",
        "destination": "James Madison",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46148889",
    "name": "Adriel Nyorha",
    "sport": "basketball",
    "position": "CG",
    "previousSchool": "South Florida",
    "destination": "Pacific",
    "season": 2026,
    "profileUrl": "basketball-profile-46148889.html",
    "stats": {
      "minutesPerGame": 10.9,
      "pointsPerGame": 3.7,
      "reboundsPerGame": 1.7,
      "assistsPerGame": 2.0,
      "stealsPerGame": 0.6,
      "blocksPerGame": 0.2,
      "fieldGoalPercentage": 39.1,
      "threePointPercentage": 32.3,
      "freeThrowPercentage": 67.9
    },
    "transferHistory": [
      {
        "recordId": "2970",
        "previousSchool": "South Florida",
        "destination": "Pacific",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46165712",
    "name": "Afan Trnka",
    "sport": "basketball",
    "position": "CG",
    "previousSchool": "UT Martin",
    "destination": "Southern Indiana",
    "season": 2026,
    "profileUrl": "basketball-profile-46165712.html",
    "stats": {
      "minutesPerGame": 24.0,
      "pointsPerGame": 6.5,
      "reboundsPerGame": 2.8,
      "assistsPerGame": 2.4,
      "stealsPerGame": 1.0,
      "blocksPerGame": 0.4,
      "fieldGoalPercentage": 32.4,
      "threePointPercentage": 28.7,
      "freeThrowPercentage": 67.6
    },
    "transferHistory": [
      {
        "recordId": "3411",
        "previousSchool": "UT Martin",
        "destination": "Southern Indiana",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46139378",
    "name": "Aiden Disu",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Holy Cross",
    "destination": "Iona",
    "season": 2026,
    "profileUrl": "basketball-profile-46139378.html",
    "stats": {
      "minutesPerGame": 27.4,
      "pointsPerGame": 10.8,
      "reboundsPerGame": 5.1,
      "assistsPerGame": 0.8,
      "stealsPerGame": 0.7,
      "blocksPerGame": 0.8,
      "fieldGoalPercentage": 45.8,
      "threePointPercentage": 29.6,
      "freeThrowPercentage": 79.7
    },
    "transferHistory": [
      {
        "recordId": "379226",
        "previousSchool": "Holy Cross",
        "destination": "Iona",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46125406",
    "name": "Aiden Sherrell",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Alabama",
    "destination": "Indiana",
    "season": 2026,
    "profileUrl": "basketball-profile-46125406.html",
    "stats": {
      "minutesPerGame": 23.9,
      "pointsPerGame": 11.1,
      "reboundsPerGame": 6.2,
      "assistsPerGame": 1.1,
      "stealsPerGame": 0.6,
      "blocksPerGame": 2.2,
      "fieldGoalPercentage": 53.9,
      "threePointPercentage": 33.8,
      "freeThrowPercentage": 71.3
    },
    "transferHistory": [
      {
        "recordId": "2906",
        "previousSchool": "Alabama",
        "destination": "Indiana",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46144829",
    "name": "Aiden Tobiason",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Temple",
    "destination": "Syracuse",
    "season": 2026,
    "profileUrl": "basketball-profile-46144829.html",
    "stats": {
      "minutesPerGame": 35.4,
      "pointsPerGame": 15.3,
      "reboundsPerGame": 3.7,
      "assistsPerGame": 2.0,
      "stealsPerGame": 1.2,
      "blocksPerGame": 0.2,
      "fieldGoalPercentage": 48.0,
      "threePointPercentage": 33.8,
      "freeThrowPercentage": 80.0
    },
    "transferHistory": [
      {
        "recordId": "2575",
        "previousSchool": "Temple",
        "destination": "Syracuse",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46132883",
    "name": "AJ Bates",
    "sport": "basketball",
    "position": "PG",
    "previousSchool": "Louisiana Tech",
    "destination": "Utah State",
    "season": 2026,
    "profileUrl": "basketball-profile-46132883.html",
    "stats": {
      "minutesPerGame": 33.4,
      "pointsPerGame": 12.1,
      "reboundsPerGame": 2.8,
      "assistsPerGame": 5.9,
      "stealsPerGame": 1.2,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 37.0,
      "threePointPercentage": 27.7,
      "freeThrowPercentage": 78.3
    },
    "transferHistory": [
      {
        "recordId": "3267",
        "previousSchool": "Louisiana Tech",
        "destination": "Utah State",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46116950",
    "name": "AJ Dancler",
    "sport": "basketball",
    "position": "PG",
    "previousSchool": "Coastal Carolina",
    "destination": "South Florida",
    "season": 2026,
    "profileUrl": "basketball-profile-46116950.html",
    "stats": {
      "minutesPerGame": 33.1,
      "pointsPerGame": 15.6,
      "reboundsPerGame": 5.5,
      "assistsPerGame": 2.1,
      "stealsPerGame": 0.8,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 40.2,
      "threePointPercentage": 39.3,
      "freeThrowPercentage": 75.7
    },
    "transferHistory": [
      {
        "recordId": "2996",
        "previousSchool": "Coastal Carolina",
        "destination": "South Florida",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46147677",
    "name": "AJ Economou",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Hawai'i",
    "destination": "Little Rock",
    "season": 2026,
    "profileUrl": "basketball-profile-46147677.html",
    "stats": {
      "minutesPerGame": 5.6,
      "pointsPerGame": 1.4,
      "reboundsPerGame": 0.6,
      "assistsPerGame": 0.1,
      "stealsPerGame": 0.4,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 29.0,
      "threePointPercentage": 18.2,
      "freeThrowPercentage": 55.6
    },
    "transferHistory": [
      {
        "recordId": "85473",
        "previousSchool": "Hawai'i",
        "destination": "Little Rock",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166053",
    "name": "AJ Lopez",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Richmond",
    "destination": "",
    "season": 2026,
    "profileUrl": "basketball-profile-46166053.html",
    "stats": {
      "minutesPerGame": 25.9,
      "pointsPerGame": 13.4,
      "reboundsPerGame": 2.2,
      "assistsPerGame": 1.3,
      "stealsPerGame": 1.0,
      "blocksPerGame": 0.5,
      "fieldGoalPercentage": 46.8,
      "threePointPercentage": 39.4,
      "freeThrowPercentage": 86.2
    },
    "transferHistory": [
      {
        "recordId": "3016",
        "previousSchool": "Richmond",
        "destination": "",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46085636",
    "name": "AJ Smith",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Temple",
    "destination": "Georgia State",
    "season": 2026,
    "profileUrl": "basketball-profile-46085636.html",
    "stats": {
      "minutesPerGame": 14.9,
      "pointsPerGame": 7.8,
      "reboundsPerGame": 1.4,
      "assistsPerGame": 0.8,
      "stealsPerGame": 0.1,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 48.9,
      "threePointPercentage": 44.4,
      "freeThrowPercentage": 73.7
    },
    "transferHistory": [
      {
        "recordId": "75103",
        "previousSchool": "Temple",
        "destination": "Georgia State",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46110087",
    "name": "AJ Storr",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Ole Miss",
    "destination": "UNLV",
    "season": 2026,
    "profileUrl": "basketball-profile-46110087.html",
    "stats": {
      "minutesPerGame": 26.3,
      "pointsPerGame": 15.5,
      "reboundsPerGame": 3.1,
      "assistsPerGame": 1.9,
      "stealsPerGame": 0.9,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 44.8,
      "threePointPercentage": 35.0,
      "freeThrowPercentage": 78.3
    },
    "transferHistory": [
      {
        "recordId": "3776607",
        "previousSchool": "Ole Miss",
        "destination": "UNLV",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46134930",
    "name": "Akai Fleming",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Georgia Tech",
    "destination": "Cincinnati",
    "season": 2026,
    "profileUrl": "basketball-profile-46134930.html",
    "stats": {
      "minutesPerGame": 25.5,
      "pointsPerGame": 10.4,
      "reboundsPerGame": 3.2,
      "assistsPerGame": 1.3,
      "stealsPerGame": 0.5,
      "blocksPerGame": 0.3,
      "fieldGoalPercentage": 37.3,
      "threePointPercentage": 32.9,
      "freeThrowPercentage": 81.6
    },
    "transferHistory": [
      {
        "recordId": "3053",
        "previousSchool": "Georgia Tech",
        "destination": "Cincinnati",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46144031",
    "name": "Akbar Waheed III",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Boston College",
    "destination": "St. Bonaventure",
    "season": 2026,
    "profileUrl": "basketball-profile-46144031.html",
    "stats": {},
    "transferHistory": [
      {
        "recordId": "3273",
        "previousSchool": "Boston College",
        "destination": "St. Bonaventure",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46118030",
    "name": "Al Amadou",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Saint Joseph's",
    "destination": "Milwaukee",
    "season": 2026,
    "profileUrl": "basketball-profile-46118030.html",
    "stats": {
      "minutesPerGame": 6.1,
      "pointsPerGame": 1.4,
      "reboundsPerGame": 0.8,
      "assistsPerGame": 0.3,
      "stealsPerGame": 0.0,
      "blocksPerGame": 0.5,
      "fieldGoalPercentage": 54.5,
      "threePointPercentage": 0.0,
      "freeThrowPercentage": 42.9
    },
    "transferHistory": [
      {
        "recordId": "2524",
        "previousSchool": "Saint Joseph's",
        "destination": "Milwaukee",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46145206",
    "name": "Al Green",
    "sport": "basketball",
    "position": "CG",
    "previousSchool": "UNLV",
    "destination": "",
    "season": 2026,
    "profileUrl": "basketball-profile-46145206.html",
    "stats": {
      "minutesPerGame": 12.7,
      "pointsPerGame": 4.4,
      "reboundsPerGame": 1.2,
      "assistsPerGame": 0.7,
      "stealsPerGame": 0.6,
      "blocksPerGame": 0.2,
      "fieldGoalPercentage": 40.7,
      "threePointPercentage": 31.1,
      "freeThrowPercentage": 87.5
    },
    "transferHistory": [
      {
        "recordId": "2602",
        "previousSchool": "UNLV",
        "destination": "",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46080626",
    "name": "Alec Oglesby",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Middle Tennessee",
    "destination": "Stetson",
    "season": 2026,
    "profileUrl": "basketball-profile-46080626.html",
    "stats": {
      "minutesPerGame": 24.0,
      "pointsPerGame": 8.3,
      "reboundsPerGame": 1.9,
      "assistsPerGame": 0.9,
      "stealsPerGame": 0.8,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 40.7,
      "threePointPercentage": 40.9,
      "freeThrowPercentage": 70.7
    },
    "transferHistory": [
      {
        "recordId": "2656",
        "previousSchool": "Middle Tennessee",
        "destination": "Stetson",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46134550",
    "name": "Aleks Alston",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Maryland",
    "destination": "UAB",
    "season": 2026,
    "profileUrl": "basketball-profile-46134550.html",
    "stats": {
      "minutesPerGame": 8.4,
      "pointsPerGame": 1.4,
      "reboundsPerGame": 1.7,
      "assistsPerGame": 0.3,
      "stealsPerGame": 0.2,
      "blocksPerGame": 0.2,
      "fieldGoalPercentage": 33.3,
      "threePointPercentage": 20.8,
      "freeThrowPercentage": 55.6
    },
    "transferHistory": [
      {
        "recordId": "2556",
        "previousSchool": "Maryland",
        "destination": "UAB",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46156205",
    "name": "Aleksa Dimitrijević",
    "sport": "basketball",
    "position": "C",
    "previousSchool": "Creighton",
    "destination": "Tulsa",
    "season": 2026,
    "profileUrl": "basketball-profile-46156205.html",
    "stats": {},
    "transferHistory": [
      {
        "recordId": "4530627",
        "previousSchool": "Creighton",
        "destination": "Tulsa",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166129",
    "name": "Aleksa Ristic",
    "sport": "basketball",
    "position": "CG",
    "previousSchool": "Indiana",
    "destination": "Belmont",
    "season": 2026,
    "profileUrl": "basketball-profile-46166129.html",
    "stats": {
      "minutesPerGame": 2.5,
      "pointsPerGame": 0.5,
      "reboundsPerGame": 0.1,
      "assistsPerGame": 0.0,
      "stealsPerGame": 0.0,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 40.0,
      "threePointPercentage": 66.7,
      "freeThrowPercentage": 0.0
    },
    "transferHistory": [
      {
        "recordId": "2712",
        "previousSchool": "Indiana",
        "destination": "Belmont",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166675",
    "name": "Aleksa Vlajic",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Buffalo",
    "destination": "Indiana State",
    "season": 2026,
    "profileUrl": "basketball-profile-46166675.html",
    "stats": {
      "minutesPerGame": 2.5,
      "pointsPerGame": 1.0,
      "reboundsPerGame": 1.0,
      "assistsPerGame": 0.0,
      "stealsPerGame": 0.0,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 50.0,
      "threePointPercentage": 0.0,
      "freeThrowPercentage": 0.0
    },
    "transferHistory": [
      {
        "recordId": "600041",
        "previousSchool": "Buffalo",
        "destination": "Indiana State",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46158578",
    "name": "Aleksas Bieliauskas",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Wisconsin",
    "destination": "South Carolina",
    "season": 2026,
    "profileUrl": "basketball-profile-46158578.html",
    "stats": {
      "minutesPerGame": 20.2,
      "pointsPerGame": 4.9,
      "reboundsPerGame": 4.4,
      "assistsPerGame": 0.9,
      "stealsPerGame": 0.2,
      "blocksPerGame": 0.6,
      "fieldGoalPercentage": 43.1,
      "threePointPercentage": 34.6,
      "freeThrowPercentage": 63.3
    },
    "transferHistory": [
      {
        "recordId": "2669",
        "previousSchool": "Wisconsin",
        "destination": "South Carolina",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166286",
    "name": "Aleksej Kostic",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "BYU",
    "destination": "Northwestern",
    "season": 2026,
    "profileUrl": "basketball-profile-46166286.html",
    "stats": {
      "minutesPerGame": 12.0,
      "pointsPerGame": 4.4,
      "reboundsPerGame": 0.9,
      "assistsPerGame": 0.4,
      "stealsPerGame": 0.3,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 36.8,
      "threePointPercentage": 36.7,
      "freeThrowPercentage": 87.5
    },
    "transferHistory": [
      {
        "recordId": "79654",
        "previousSchool": "BYU",
        "destination": "Northwestern",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46165799",
    "name": "Alessandro Perotti",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Wofford",
    "destination": "South Carolina Upstate",
    "season": 2026,
    "profileUrl": "basketball-profile-46165799.html",
    "stats": {},
    "transferHistory": [
      {
        "recordId": "3344",
        "previousSchool": "Wofford",
        "destination": "South Carolina Upstate",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166035",
    "name": "Alex Bruskotter",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Wright State",
    "destination": "Cleveland State",
    "season": 2026,
    "profileUrl": "basketball-profile-46166035.html",
    "stats": {
      "minutesPerGame": 8.3,
      "pointsPerGame": 4.5,
      "reboundsPerGame": 1.5,
      "assistsPerGame": 0.2,
      "stealsPerGame": 0.4,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 58.8,
      "threePointPercentage": 60.0,
      "freeThrowPercentage": 80.0
    },
    "transferHistory": [
      {
        "recordId": "3042",
        "previousSchool": "Wright State",
        "destination": "Cleveland State",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46165865",
    "name": "Alex Farley",
    "sport": "basketball",
    "position": "PG",
    "previousSchool": "Ball State",
    "destination": "",
    "season": 2026,
    "profileUrl": "basketball-profile-46165865.html",
    "stats": {
      "minutesPerGame": 1.0,
      "pointsPerGame": 0.0,
      "reboundsPerGame": 1.0,
      "assistsPerGame": 0.0,
      "stealsPerGame": 0.0,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 0.0,
      "threePointPercentage": 0.0,
      "freeThrowPercentage": 0.0
    },
    "transferHistory": [
      {
        "recordId": "3288",
        "previousSchool": "Ball State",
        "destination": "",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46165903",
    "name": "Alex Mirhosseini",
    "sport": "basketball",
    "position": "PG",
    "previousSchool": "Arkansas-Pine Bluff",
    "destination": "",
    "season": 2026,
    "profileUrl": "basketball-profile-46165903.html",
    "stats": {
      "minutesPerGame": 31.8,
      "pointsPerGame": 11.7,
      "reboundsPerGame": 2.4,
      "assistsPerGame": 2.7,
      "stealsPerGame": 1.5,
      "blocksPerGame": 0.3,
      "fieldGoalPercentage": 35.4,
      "threePointPercentage": 33.2,
      "freeThrowPercentage": 71.2
    },
    "transferHistory": [
      {
        "recordId": "3256",
        "previousSchool": "Arkansas-Pine Bluff",
        "destination": "",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166002",
    "name": "Alex Wilkins",
    "sport": "basketball",
    "position": "CG",
    "previousSchool": "Furman",
    "destination": "Kentucky",
    "season": 2026,
    "profileUrl": "basketball-profile-46166002.html",
    "stats": {
      "minutesPerGame": 29.7,
      "pointsPerGame": 17.8,
      "reboundsPerGame": 2.0,
      "assistsPerGame": 4.7,
      "stealsPerGame": 0.8,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 46.0,
      "threePointPercentage": 32.8,
      "freeThrowPercentage": 82.4
    },
    "transferHistory": [
      {
        "recordId": "3104",
        "previousSchool": "Furman",
        "destination": "Kentucky",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46125576",
    "name": "Alier Maluk",
    "sport": "basketball",
    "position": "C",
    "previousSchool": "Florida State",
    "destination": "McNeese",
    "season": 2026,
    "profileUrl": "basketball-profile-46125576.html",
    "stats": {
      "minutesPerGame": 6.2,
      "pointsPerGame": 1.6,
      "reboundsPerGame": 1.7,
      "assistsPerGame": 0.3,
      "stealsPerGame": 0.2,
      "blocksPerGame": 0.4,
      "fieldGoalPercentage": 36.4,
      "threePointPercentage": 28.6,
      "freeThrowPercentage": 56.3
    },
    "transferHistory": [
      {
        "recordId": "3006",
        "previousSchool": "Florida State",
        "destination": "McNeese",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46156969",
    "name": "All Wright",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Xavier",
    "destination": "Loyola Marymount",
    "season": 2026,
    "profileUrl": "basketball-profile-46156969.html",
    "stats": {
      "minutesPerGame": 22.2,
      "pointsPerGame": 7.5,
      "reboundsPerGame": 1.6,
      "assistsPerGame": 2.0,
      "stealsPerGame": 0.5,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 46.2,
      "threePointPercentage": 42.2,
      "freeThrowPercentage": 84.1
    },
    "transferHistory": [
      {
        "recordId": "3427",
        "previousSchool": "Xavier",
        "destination": "Loyola Marymount",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166131",
    "name": "Alon Michaeli",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Colorado",
    "destination": "Saint Louis",
    "season": 2026,
    "profileUrl": "basketball-profile-46166131.html",
    "stats": {
      "minutesPerGame": 17.5,
      "pointsPerGame": 7.1,
      "reboundsPerGame": 3.9,
      "assistsPerGame": 1.0,
      "stealsPerGame": 0.5,
      "blocksPerGame": 0.2,
      "fieldGoalPercentage": 40.1,
      "threePointPercentage": 29.0,
      "freeThrowPercentage": 72.2
    },
    "transferHistory": [
      {
        "recordId": "2671",
        "previousSchool": "Colorado",
        "destination": "Saint Louis",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46157201",
    "name": "Alvaro Folgueiras",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Iowa",
    "destination": "Louisville",
    "season": 2026,
    "profileUrl": "basketball-profile-46157201.html",
    "stats": {
      "minutesPerGame": 20.8,
      "pointsPerGame": 8.4,
      "reboundsPerGame": 3.6,
      "assistsPerGame": 2.2,
      "stealsPerGame": 0.9,
      "blocksPerGame": 0.2,
      "fieldGoalPercentage": 50.0,
      "threePointPercentage": 33.3,
      "freeThrowPercentage": 76.7
    },
    "transferHistory": [
      {
        "recordId": "2423",
        "previousSchool": "Iowa",
        "destination": "Louisville",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46153070",
    "name": "Alvin Jackson III",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Utah",
    "destination": "Weber State",
    "season": 2026,
    "profileUrl": "basketball-profile-46153070.html",
    "stats": {},
    "transferHistory": [
      {
        "recordId": "2867",
        "previousSchool": "Utah",
        "destination": "Weber State",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166397",
    "name": "Aly Tounkara",
    "sport": "basketball",
    "position": "C",
    "previousSchool": "Arkansas State",
    "destination": "Boston College",
    "season": 2026,
    "profileUrl": "basketball-profile-46166397.html",
    "stats": {
      "minutesPerGame": 18.2,
      "pointsPerGame": 4.2,
      "reboundsPerGame": 5.5,
      "assistsPerGame": 0.5,
      "stealsPerGame": 0.4,
      "blocksPerGame": 1.0,
      "fieldGoalPercentage": 62.9,
      "threePointPercentage": 0.0,
      "freeThrowPercentage": 36.8
    },
    "transferHistory": [
      {
        "recordId": "219188",
        "previousSchool": "Arkansas State",
        "destination": "Boston College",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46055487",
    "name": "Alyn Breed",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "NC State",
    "destination": "UNLV",
    "season": 2026,
    "profileUrl": "basketball-profile-46055487.html",
    "stats": {
      "minutesPerGame": 14.8,
      "pointsPerGame": 4.5,
      "reboundsPerGame": 1.9,
      "assistsPerGame": 1.3,
      "stealsPerGame": 0.7,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 40.5,
      "threePointPercentage": 34.5,
      "freeThrowPercentage": 89.3
    },
    "transferHistory": [
      {
        "recordId": "2474",
        "previousSchool": "NC State",
        "destination": "UNLV",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46144621",
    "name": "Amadou Doumbia",
    "sport": "basketball",
    "position": "C",
    "previousSchool": "North Carolina A&T",
    "destination": "Arkansas State",
    "season": 2026,
    "profileUrl": "basketball-profile-46144621.html",
    "stats": {
      "minutesPerGame": 13.9,
      "pointsPerGame": 3.4,
      "reboundsPerGame": 4.0,
      "assistsPerGame": 0.2,
      "stealsPerGame": 0.5,
      "blocksPerGame": 1.3,
      "fieldGoalPercentage": 51.5,
      "threePointPercentage": 0.0,
      "freeThrowPercentage": 63.9
    },
    "transferHistory": [
      {
        "recordId": "2786",
        "previousSchool": "North Carolina A&T",
        "destination": "Arkansas State",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46130949",
    "name": "Amani Lyles",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Akron",
    "destination": "Cincinnati",
    "season": 2026,
    "profileUrl": "basketball-profile-46130949.html",
    "stats": {
      "minutesPerGame": 26.4,
      "pointsPerGame": 14.9,
      "reboundsPerGame": 7.9,
      "assistsPerGame": 2.2,
      "stealsPerGame": 1.0,
      "blocksPerGame": 0.7,
      "fieldGoalPercentage": 55.8,
      "threePointPercentage": 37.3,
      "freeThrowPercentage": 71.6
    },
    "transferHistory": [
      {
        "recordId": "6560989",
        "previousSchool": "Akron",
        "destination": "Cincinnati",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166352",
    "name": "Amar Amkou",
    "sport": "basketball",
    "position": "SF",
    "previousSchool": "Florida Atlantic",
    "destination": "North Texas",
    "season": 2026,
    "profileUrl": "basketball-profile-46166352.html",
    "stats": {
      "minutesPerGame": 12.5,
      "pointsPerGame": 5.5,
      "reboundsPerGame": 2.2,
      "assistsPerGame": 0.4,
      "stealsPerGame": 0.4,
      "blocksPerGame": 0.4,
      "fieldGoalPercentage": 44.1,
      "threePointPercentage": 36.4,
      "freeThrowPercentage": 79.2
    },
    "transferHistory": [
      {
        "recordId": "133517",
        "previousSchool": "Florida Atlantic",
        "destination": "North Texas",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46156867",
    "name": "Amar Kuljuhovic",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Missouri State",
    "destination": "",
    "season": 2026,
    "profileUrl": "basketball-profile-46156867.html",
    "stats": {
      "minutesPerGame": 12.5,
      "pointsPerGame": 7.5,
      "reboundsPerGame": 6.0,
      "assistsPerGame": 1.5,
      "stealsPerGame": 0.0,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 55.6,
      "threePointPercentage": 0.0,
      "freeThrowPercentage": 71.4
    },
    "transferHistory": [
      {
        "recordId": "2652",
        "previousSchool": "Missouri State",
        "destination": "",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46057974",
    "name": "Amar'e Marshall",
    "sport": "basketball",
    "position": "CG",
    "previousSchool": "St. Bonaventure",
    "destination": "",
    "season": 2026,
    "profileUrl": "basketball-profile-46057974.html",
    "stats": {
      "minutesPerGame": 13.4,
      "pointsPerGame": 4.7,
      "reboundsPerGame": 1.9,
      "assistsPerGame": 1.4,
      "stealsPerGame": 0.5,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 48.8,
      "threePointPercentage": 33.3,
      "freeThrowPercentage": 60.0
    },
    "transferHistory": [
      {
        "recordId": "2458",
        "previousSchool": "St. Bonaventure",
        "destination": "",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166385",
    "name": "Amaree Brown",
    "sport": "basketball",
    "position": "SF",
    "previousSchool": "Southern Indiana",
    "destination": "Alabama State",
    "season": 2026,
    "profileUrl": "basketball-profile-46166385.html",
    "stats": {
      "minutesPerGame": 26.4,
      "pointsPerGame": 13.8,
      "reboundsPerGame": 2.8,
      "assistsPerGame": 1.2,
      "stealsPerGame": 0.6,
      "blocksPerGame": 0.4,
      "fieldGoalPercentage": 36.8,
      "threePointPercentage": 28.8,
      "freeThrowPercentage": 78.5
    },
    "transferHistory": [
      {
        "recordId": "189967",
        "previousSchool": "Southern Indiana",
        "destination": "Alabama State",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46134851",
    "name": "Amari Evans",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Tennessee",
    "destination": "Texas",
    "season": 2026,
    "profileUrl": "basketball-profile-46134851.html",
    "stats": {
      "minutesPerGame": 14.4,
      "pointsPerGame": 4.1,
      "reboundsPerGame": 3.2,
      "assistsPerGame": 0.8,
      "stealsPerGame": 1.0,
      "blocksPerGame": 0.2,
      "fieldGoalPercentage": 41.9,
      "threePointPercentage": 22.0,
      "freeThrowPercentage": 57.5
    },
    "transferHistory": [
      {
        "recordId": "2645",
        "previousSchool": "Tennessee",
        "destination": "Texas",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46142067",
    "name": "Amari Reed",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "UT Arlington",
    "destination": "Stephen F. Austin",
    "season": 2026,
    "profileUrl": "basketball-profile-46142067.html",
    "stats": {
      "minutesPerGame": 10.5,
      "pointsPerGame": 2.9,
      "reboundsPerGame": 2.4,
      "assistsPerGame": 0.1,
      "stealsPerGame": 0.5,
      "blocksPerGame": 0.7,
      "fieldGoalPercentage": 59.6,
      "threePointPercentage": 0.0,
      "freeThrowPercentage": 55.6
    },
    "transferHistory": [
      {
        "recordId": "2913",
        "previousSchool": "UT Arlington",
        "destination": "Stephen F. Austin",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46116024",
    "name": "Amarion Dickerson",
    "sport": "basketball",
    "position": "CG",
    "previousSchool": "USC",
    "destination": "Grand Canyon",
    "season": 2026,
    "profileUrl": "basketball-profile-46116024.html",
    "stats": {
      "minutesPerGame": 21.6,
      "pointsPerGame": 4.6,
      "reboundsPerGame": 3.4,
      "assistsPerGame": 1.1,
      "stealsPerGame": 0.8,
      "blocksPerGame": 0.9,
      "fieldGoalPercentage": 50.0,
      "threePointPercentage": 44.4,
      "freeThrowPercentage": 61.1
    },
    "transferHistory": [
      {
        "recordId": "2883",
        "previousSchool": "USC",
        "destination": "Grand Canyon",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46116971",
    "name": "Amarri Monroe",
    "sport": "basketball",
    "position": "SF",
    "previousSchool": "Quinnipiac",
    "destination": "Syracuse",
    "season": 2026,
    "profileUrl": "basketball-profile-46116971.html",
    "stats": {
      "minutesPerGame": 33.3,
      "pointsPerGame": 15.6,
      "reboundsPerGame": 8.3,
      "assistsPerGame": 2.2,
      "stealsPerGame": 2.3,
      "blocksPerGame": 0.9,
      "fieldGoalPercentage": 41.3,
      "threePointPercentage": 27.5,
      "freeThrowPercentage": 76.2
    },
    "transferHistory": [
      {
        "recordId": "2951",
        "previousSchool": "Quinnipiac",
        "destination": "Syracuse",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46112707",
    "name": "Amier Ali",
    "sport": "basketball",
    "position": "SF",
    "previousSchool": "Mississippi State",
    "destination": "California",
    "season": 2026,
    "profileUrl": "basketball-profile-46112707.html",
    "stats": {
      "minutesPerGame": 7.3,
      "pointsPerGame": 3.2,
      "reboundsPerGame": 1.7,
      "assistsPerGame": 0.2,
      "stealsPerGame": 0.2,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 34.2,
      "threePointPercentage": 30.8,
      "freeThrowPercentage": 57.1
    },
    "transferHistory": [
      {
        "recordId": "2765",
        "previousSchool": "Mississippi State",
        "destination": "California",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46165827",
    "name": "Amir Lindsey",
    "sport": "basketball",
    "position": "PG",
    "previousSchool": "UAlbany",
    "destination": "Fordham",
    "season": 2026,
    "profileUrl": "basketball-profile-46165827.html",
    "stats": {
      "minutesPerGame": 37.6,
      "pointsPerGame": 17.9,
      "reboundsPerGame": 3.3,
      "assistsPerGame": 4.9,
      "stealsPerGame": 1.2,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 44.7,
      "threePointPercentage": 34.9,
      "freeThrowPercentage": 79.2
    },
    "transferHistory": [
      {
        "recordId": "3322",
        "previousSchool": "UAlbany",
        "destination": "Fordham",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46132710",
    "name": "Amir Williams",
    "sport": "basketball",
    "position": "SF",
    "previousSchool": "Hofstra",
    "destination": "West Georgia",
    "season": 2026,
    "profileUrl": "basketball-profile-46132710.html",
    "stats": {
      "minutesPerGame": 5.7,
      "pointsPerGame": 1.3,
      "reboundsPerGame": 1.7,
      "assistsPerGame": 0.0,
      "stealsPerGame": 1.0,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 50.0,
      "threePointPercentage": 0.0,
      "freeThrowPercentage": 0.0
    },
    "transferHistory": [
      {
        "recordId": "2787",
        "previousSchool": "Hofstra",
        "destination": "West Georgia",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46144994",
    "name": "Amire Robinson",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Nevada",
    "destination": "Oral Roberts",
    "season": 2026,
    "profileUrl": "basketball-profile-46144994.html",
    "stats": {
      "minutesPerGame": 9.4,
      "pointsPerGame": 2.7,
      "reboundsPerGame": 1.1,
      "assistsPerGame": 0.4,
      "stealsPerGame": 0.2,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 45.3,
      "threePointPercentage": 33.3,
      "freeThrowPercentage": 70.6
    },
    "transferHistory": [
      {
        "recordId": "2722",
        "previousSchool": "Nevada",
        "destination": "Oral Roberts",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166353",
    "name": "Amon Dorries",
    "sport": "basketball",
    "position": "C",
    "previousSchool": "Bucknell",
    "destination": "Richmond",
    "season": 2026,
    "profileUrl": "basketball-profile-46166353.html",
    "stats": {
      "minutesPerGame": 32.5,
      "pointsPerGame": 16.2,
      "reboundsPerGame": 4.4,
      "assistsPerGame": 1.4,
      "stealsPerGame": 0.8,
      "blocksPerGame": 0.4,
      "fieldGoalPercentage": 54.0,
      "threePointPercentage": 33.3,
      "freeThrowPercentage": 78.8
    },
    "transferHistory": [
      {
        "recordId": "134750",
        "previousSchool": "Bucknell",
        "destination": "Richmond",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166122",
    "name": "Andre Pasha",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "New Haven",
    "destination": "Bryant",
    "season": 2026,
    "profileUrl": "basketball-profile-46166122.html",
    "stats": {
      "minutesPerGame": 31.7,
      "pointsPerGame": 10.7,
      "reboundsPerGame": 5.2,
      "assistsPerGame": 1.8,
      "stealsPerGame": 0.8,
      "blocksPerGame": 0.7,
      "fieldGoalPercentage": 44.7,
      "threePointPercentage": 35.1,
      "freeThrowPercentage": 82.9
    },
    "transferHistory": [
      {
        "recordId": "2836",
        "previousSchool": "New Haven",
        "destination": "Bryant",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46152399",
    "name": "Andreas Holst",
    "sport": "basketball",
    "position": "C",
    "previousSchool": "Oklahoma",
    "destination": "Florida International",
    "season": 2026,
    "profileUrl": "basketball-profile-46152399.html",
    "stats": {},
    "transferHistory": [
      {
        "recordId": "2589",
        "previousSchool": "Oklahoma",
        "destination": "Florida International",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166302",
    "name": "Andrej Acimovic",
    "sport": "basketball",
    "position": "C",
    "previousSchool": "Indiana",
    "destination": "Missouri State",
    "season": 2026,
    "profileUrl": "basketball-profile-46166302.html",
    "stats": {},
    "transferHistory": [
      {
        "recordId": "84308",
        "previousSchool": "Indiana",
        "destination": "Missouri State",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166363",
    "name": "Andrej Shoshkikj",
    "sport": "basketball",
    "position": "CG",
    "previousSchool": "Stony Brook",
    "destination": "South Florida",
    "season": 2026,
    "profileUrl": "basketball-profile-46166363.html",
    "stats": {
      "minutesPerGame": 25.9,
      "pointsPerGame": 10.7,
      "reboundsPerGame": 2.6,
      "assistsPerGame": 2.4,
      "stealsPerGame": 1.5,
      "blocksPerGame": 0.2,
      "fieldGoalPercentage": 49.8,
      "threePointPercentage": 45.1,
      "freeThrowPercentage": 96.4
    },
    "transferHistory": [
      {
        "recordId": "159867",
        "previousSchool": "Stony Brook",
        "destination": "South Florida",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166416",
    "name": "Andrew Ball",
    "sport": "basketball",
    "position": "SF",
    "previousSchool": "Monmouth",
    "destination": "Richmond",
    "season": 2026,
    "profileUrl": "basketball-profile-46166416.html",
    "stats": {
      "minutesPerGame": 20.5,
      "pointsPerGame": 7.9,
      "reboundsPerGame": 3.9,
      "assistsPerGame": 0.6,
      "stealsPerGame": 0.6,
      "blocksPerGame": 0.6,
      "fieldGoalPercentage": 50.5,
      "threePointPercentage": 30.5,
      "freeThrowPercentage": 60.0
    },
    "transferHistory": [
      {
        "recordId": "228375",
        "previousSchool": "Monmouth",
        "destination": "Richmond",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46134964",
    "name": "Andrew Crawford",
    "sport": "basketball",
    "position": "CG",
    "previousSchool": "Colorado",
    "destination": "Northern Colorado",
    "season": 2026,
    "profileUrl": "basketball-profile-46134964.html",
    "stats": {
      "minutesPerGame": 4.8,
      "pointsPerGame": 1.4,
      "reboundsPerGame": 0.6,
      "assistsPerGame": 0.3,
      "stealsPerGame": 0.3,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 50.0,
      "threePointPercentage": 60.0,
      "freeThrowPercentage": 50.0
    },
    "transferHistory": [
      {
        "recordId": "2741",
        "previousSchool": "Colorado",
        "destination": "Northern Colorado",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46140213",
    "name": "Andrew McKeever",
    "sport": "basketball",
    "position": "C",
    "previousSchool": "Saint Mary's",
    "destination": "Iowa",
    "season": 2026,
    "profileUrl": "basketball-profile-46140213.html",
    "stats": {
      "minutesPerGame": 23.2,
      "pointsPerGame": 8.2,
      "reboundsPerGame": 9.2,
      "assistsPerGame": 1.8,
      "stealsPerGame": 0.5,
      "blocksPerGame": 0.8,
      "fieldGoalPercentage": 50.0,
      "threePointPercentage": 0.0,
      "freeThrowPercentage": 62.8
    },
    "transferHistory": [
      {
        "recordId": "3194",
        "previousSchool": "Saint Mary's",
        "destination": "Iowa",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46117805",
    "name": "Andrew Meadow",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Boise State",
    "destination": "Oregon",
    "season": 2026,
    "profileUrl": "basketball-profile-46117805.html",
    "stats": {
      "minutesPerGame": 29.9,
      "pointsPerGame": 12.1,
      "reboundsPerGame": 3.6,
      "assistsPerGame": 1.0,
      "stealsPerGame": 0.6,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 51.0,
      "threePointPercentage": 38.6,
      "freeThrowPercentage": 65.5
    },
    "transferHistory": [
      {
        "recordId": "3054",
        "previousSchool": "Boise State",
        "destination": "Oregon",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46165907",
    "name": "Andrew Phillips",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Lafayette",
    "destination": "George Washington",
    "season": 2026,
    "profileUrl": "basketball-profile-46165907.html",
    "stats": {
      "minutesPerGame": 33.4,
      "pointsPerGame": 13.9,
      "reboundsPerGame": 4.6,
      "assistsPerGame": 1.3,
      "stealsPerGame": 1.2,
      "blocksPerGame": 0.2,
      "fieldGoalPercentage": 39.8,
      "threePointPercentage": 31.1,
      "freeThrowPercentage": 71.3
    },
    "transferHistory": [
      {
        "recordId": "3248",
        "previousSchool": "Lafayette",
        "destination": "George Washington",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46109444",
    "name": "Andrew Rohde",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Wisconsin",
    "destination": "",
    "season": 2026,
    "profileUrl": "basketball-profile-46109444.html",
    "stats": {
      "minutesPerGame": 26.4,
      "pointsPerGame": 5.7,
      "reboundsPerGame": 2.1,
      "assistsPerGame": 2.9,
      "stealsPerGame": 1.2,
      "blocksPerGame": 0.2,
      "fieldGoalPercentage": 36.3,
      "threePointPercentage": 31.8,
      "freeThrowPercentage": 77.8
    },
    "transferHistory": [
      {
        "recordId": "6554742",
        "previousSchool": "Wisconsin",
        "destination": "",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46165815",
    "name": "Andrija Bukumirovic",
    "sport": "basketball",
    "position": "SF",
    "previousSchool": "UT Martin",
    "destination": "Boston College",
    "season": 2026,
    "profileUrl": "basketball-profile-46165815.html",
    "stats": {
      "minutesPerGame": 29.3,
      "pointsPerGame": 13.8,
      "reboundsPerGame": 7.8,
      "assistsPerGame": 1.0,
      "stealsPerGame": 1.2,
      "blocksPerGame": 0.9,
      "fieldGoalPercentage": 51.6,
      "threePointPercentage": 36.4,
      "freeThrowPercentage": 57.5
    },
    "transferHistory": [
      {
        "recordId": "3337",
        "previousSchool": "UT Martin",
        "destination": "Boston College",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46158582",
    "name": "Andrija Grbovic",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Arizona State",
    "destination": "Oklahoma State",
    "season": 2026,
    "profileUrl": "basketball-profile-46158582.html",
    "stats": {
      "minutesPerGame": 19.8,
      "pointsPerGame": 6.8,
      "reboundsPerGame": 2.9,
      "assistsPerGame": 0.4,
      "stealsPerGame": 0.5,
      "blocksPerGame": 0.2,
      "fieldGoalPercentage": 40.4,
      "threePointPercentage": 35.0,
      "freeThrowPercentage": 78.9
    },
    "transferHistory": [
      {
        "recordId": "312434",
        "previousSchool": "Arizona State",
        "destination": "Oklahoma State",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46157754",
    "name": "Andrija Jelavic",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Kentucky",
    "destination": "Ohio State",
    "season": 2026,
    "profileUrl": "basketball-profile-46157754.html",
    "stats": {
      "minutesPerGame": 15.6,
      "pointsPerGame": 5.5,
      "reboundsPerGame": 4.0,
      "assistsPerGame": 0.7,
      "stealsPerGame": 0.4,
      "blocksPerGame": 0.3,
      "fieldGoalPercentage": 47.7,
      "threePointPercentage": 27.6,
      "freeThrowPercentage": 53.3
    },
    "transferHistory": [
      {
        "recordId": "2792512",
        "previousSchool": "Ohio State",
        "destination": "Ohio State",
        "season": "2026"
      },
      {
        "recordId": "2748",
        "previousSchool": "Kentucky",
        "destination": "Ohio State",
        "season": "2026"
      }
    ],
    "needsReview": true
  },
  {
    "playerId": "46153816",
    "name": "Andrija Vukovic",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Oklahoma State",
    "destination": "George Washington",
    "season": 2026,
    "profileUrl": "basketball-profile-46153816.html",
    "stats": {
      "minutesPerGame": 15.3,
      "pointsPerGame": 5.3,
      "reboundsPerGame": 3.4,
      "assistsPerGame": 0.6,
      "stealsPerGame": 0.5,
      "blocksPerGame": 0.4,
      "fieldGoalPercentage": 62.2,
      "threePointPercentage": 33.3,
      "freeThrowPercentage": 69.0
    },
    "transferHistory": [
      {
        "recordId": "2452",
        "previousSchool": "Oklahoma State",
        "destination": "George Washington",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46085167",
    "name": "Angelo Brizzi",
    "sport": "basketball",
    "position": "PG",
    "previousSchool": "Buffalo",
    "destination": "North Carolina",
    "season": 2026,
    "profileUrl": "basketball-profile-46085167.html",
    "stats": {
      "minutesPerGame": 29.8,
      "pointsPerGame": 14.5,
      "reboundsPerGame": 2.8,
      "assistsPerGame": 1.8,
      "stealsPerGame": 1.8,
      "blocksPerGame": 0.3,
      "fieldGoalPercentage": 48.0,
      "threePointPercentage": 37.3,
      "freeThrowPercentage": 83.4
    },
    "transferHistory": [
      {
        "recordId": "2882032",
        "previousSchool": "Buffalo",
        "destination": "North Carolina",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46157250",
    "name": "Anquan Boldin Jr.",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Florida A&M",
    "destination": "Stonehill",
    "season": 2026,
    "profileUrl": "basketball-profile-46157250.html",
    "stats": {
      "minutesPerGame": 18.1,
      "pointsPerGame": 5.8,
      "reboundsPerGame": 3.0,
      "assistsPerGame": 0.9,
      "stealsPerGame": 0.8,
      "blocksPerGame": 0.2,
      "fieldGoalPercentage": 48.5,
      "threePointPercentage": 21.1,
      "freeThrowPercentage": 47.5
    },
    "transferHistory": [
      {
        "recordId": "2768",
        "previousSchool": "Florida A&M",
        "destination": "Stonehill",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46158114",
    "name": "Anthony Enoh",
    "sport": "basketball",
    "position": "SF",
    "previousSchool": "Georgia State",
    "destination": "Kennesaw State",
    "season": 2026,
    "profileUrl": "basketball-profile-46158114.html",
    "stats": {
      "minutesPerGame": 22.2,
      "pointsPerGame": 5.0,
      "reboundsPerGame": 5.0,
      "assistsPerGame": 0.8,
      "stealsPerGame": 0.6,
      "blocksPerGame": 0.6,
      "fieldGoalPercentage": 33.8,
      "threePointPercentage": 23.3,
      "freeThrowPercentage": 65.2
    },
    "transferHistory": [
      {
        "recordId": "2703",
        "previousSchool": "Georgia State",
        "destination": "Kennesaw State",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46117350",
    "name": "Anthony Finkley",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Saint Joseph's",
    "destination": "La Salle",
    "season": 2026,
    "profileUrl": "basketball-profile-46117350.html",
    "stats": {
      "minutesPerGame": 19.0,
      "pointsPerGame": 5.4,
      "reboundsPerGame": 3.3,
      "assistsPerGame": 1.6,
      "stealsPerGame": 0.2,
      "blocksPerGame": 0.2,
      "fieldGoalPercentage": 28.8,
      "threePointPercentage": 28.8,
      "freeThrowPercentage": 80.8
    },
    "transferHistory": [
      {
        "recordId": "2634",
        "previousSchool": "Saint Joseph's",
        "destination": "La Salle",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46159337",
    "name": "Anthony Johnson",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Arizona State",
    "destination": "",
    "season": 2026,
    "profileUrl": "basketball-profile-46159337.html",
    "stats": {
      "minutesPerGame": 24.8,
      "pointsPerGame": 13.2,
      "reboundsPerGame": 3.2,
      "assistsPerGame": 1.7,
      "stealsPerGame": 1.3,
      "blocksPerGame": 0.3,
      "fieldGoalPercentage": 45.4,
      "threePointPercentage": 32.9,
      "freeThrowPercentage": 76.1
    },
    "transferHistory": [
      {
        "recordId": "8617",
        "previousSchool": "Arizona State",
        "destination": "",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46135536",
    "name": "Anthony Robinson",
    "sport": "basketball",
    "position": "C",
    "previousSchool": "Xavier",
    "destination": "Pepperdine",
    "season": 2026,
    "profileUrl": "basketball-profile-46135536.html",
    "stats": {
      "minutesPerGame": 10.0,
      "pointsPerGame": 2.3,
      "reboundsPerGame": 2.4,
      "assistsPerGame": 0.3,
      "stealsPerGame": 0.3,
      "blocksPerGame": 0.5,
      "fieldGoalPercentage": 54.3,
      "threePointPercentage": 0.0,
      "freeThrowPercentage": 43.4
    },
    "transferHistory": [
      {
        "recordId": "3393",
        "previousSchool": "Xavier",
        "destination": "Pepperdine",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46113945",
    "name": "Anthony Robinson II",
    "sport": "basketball",
    "position": "PG",
    "previousSchool": "Missouri",
    "destination": "Florida State",
    "season": 2026,
    "profileUrl": "basketball-profile-46113945.html",
    "stats": {
      "minutesPerGame": 27.1,
      "pointsPerGame": 8.9,
      "reboundsPerGame": 3.1,
      "assistsPerGame": 3.0,
      "stealsPerGame": 1.6,
      "blocksPerGame": 0.3,
      "fieldGoalPercentage": 41.0,
      "threePointPercentage": 31.4,
      "freeThrowPercentage": 67.0
    },
    "transferHistory": [
      {
        "recordId": "3164",
        "previousSchool": "Missouri",
        "destination": "Florida State",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46141257",
    "name": "Anthony Roy",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Oklahoma State",
    "destination": "",
    "season": 2026,
    "profileUrl": "basketball-profile-46141257.html",
    "stats": {
      "minutesPerGame": 28.7,
      "pointsPerGame": 16.9,
      "reboundsPerGame": 4.1,
      "assistsPerGame": 1.3,
      "stealsPerGame": 0.5,
      "blocksPerGame": 0.2,
      "fieldGoalPercentage": 43.1,
      "threePointPercentage": 39.0,
      "freeThrowPercentage": 85.7
    },
    "transferHistory": [
      {
        "recordId": "2706",
        "previousSchool": "Oklahoma State",
        "destination": "",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46160180",
    "name": "Anthony Smith III",
    "sport": "basketball",
    "position": "PG",
    "previousSchool": "North Dakota",
    "destination": "Winthrop",
    "season": 2026,
    "profileUrl": "basketball-profile-46160180.html",
    "stats": {
      "minutesPerGame": 17.7,
      "pointsPerGame": 7.8,
      "reboundsPerGame": 2.1,
      "assistsPerGame": 2.3,
      "stealsPerGame": 0.7,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 47.1,
      "threePointPercentage": 23.4,
      "freeThrowPercentage": 83.8
    },
    "transferHistory": [
      {
        "recordId": "3365",
        "previousSchool": "North Dakota",
        "destination": "Winthrop",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46153132",
    "name": "Anton Bonke",
    "sport": "basketball",
    "position": "C",
    "previousSchool": "Charlotte",
    "destination": "Michigan State",
    "season": 2026,
    "profileUrl": "basketball-profile-46153132.html",
    "stats": {
      "minutesPerGame": 25.6,
      "pointsPerGame": 10.6,
      "reboundsPerGame": 8.3,
      "assistsPerGame": 1.0,
      "stealsPerGame": 0.2,
      "blocksPerGame": 1.5,
      "fieldGoalPercentage": 57.6,
      "threePointPercentage": 34.2,
      "freeThrowPercentage": 65.3
    },
    "transferHistory": [
      {
        "recordId": "3335",
        "previousSchool": "Charlotte",
        "destination": "Michigan State",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46117641",
    "name": "Antonio Chol",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "New Mexico",
    "destination": "UC Santa Barbara",
    "season": 2026,
    "profileUrl": "basketball-profile-46117641.html",
    "stats": {
      "minutesPerGame": 24.2,
      "pointsPerGame": 7.7,
      "reboundsPerGame": 2.9,
      "assistsPerGame": 0.8,
      "stealsPerGame": 0.3,
      "blocksPerGame": 0.6,
      "fieldGoalPercentage": 38.7,
      "threePointPercentage": 32.3,
      "freeThrowPercentage": 60.0
    },
    "transferHistory": [
      {
        "recordId": "53436",
        "previousSchool": "New Mexico",
        "destination": "UC Santa Barbara",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46158579",
    "name": "Antonio Dorn",
    "sport": "basketball",
    "position": "C",
    "previousSchool": "Virginia Tech",
    "destination": "Wake Forest",
    "season": 2026,
    "profileUrl": "basketball-profile-46158579.html",
    "stats": {
      "minutesPerGame": 8.5,
      "pointsPerGame": 2.6,
      "reboundsPerGame": 1.8,
      "assistsPerGame": 0.4,
      "stealsPerGame": 0.1,
      "blocksPerGame": 0.2,
      "fieldGoalPercentage": 64.3,
      "threePointPercentage": 0.0,
      "freeThrowPercentage": 50.0
    },
    "transferHistory": [
      {
        "recordId": "2770",
        "previousSchool": "Virginia Tech",
        "destination": "Wake Forest",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46143762",
    "name": "Antonio Munoz",
    "sport": "basketball",
    "position": "SF",
    "previousSchool": "Grambling",
    "destination": "San Diego",
    "season": 2026,
    "profileUrl": "basketball-profile-46143762.html",
    "stats": {
      "minutesPerGame": 24.8,
      "pointsPerGame": 12.5,
      "reboundsPerGame": 3.5,
      "assistsPerGame": 2.0,
      "stealsPerGame": 0.7,
      "blocksPerGame": 0.5,
      "fieldGoalPercentage": 47.2,
      "threePointPercentage": 5.9,
      "freeThrowPercentage": 66.3
    },
    "transferHistory": [
      {
        "recordId": "2519",
        "previousSchool": "Grambling",
        "destination": "San Diego",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "84365",
    "name": "Antwann Jones",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "UNC Greensboro",
    "destination": "",
    "season": 2026,
    "profileUrl": "basketball-profile-84365.html",
    "stats": {
      "minutesPerGame": 11.4,
      "pointsPerGame": 3.4,
      "reboundsPerGame": 2.1,
      "assistsPerGame": 0.4,
      "stealsPerGame": 0.3,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 41.7,
      "threePointPercentage": 37.5,
      "freeThrowPercentage": 50.0
    },
    "transferHistory": [
      {
        "recordId": "319274",
        "previousSchool": "UNC Greensboro",
        "destination": "",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46136981",
    "name": "Ari Fulton",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "NJIT",
    "destination": "St. Bonaventure",
    "season": 2026,
    "profileUrl": "basketball-profile-46136981.html",
    "stats": {
      "minutesPerGame": 28.3,
      "pointsPerGame": 10.9,
      "reboundsPerGame": 6.2,
      "assistsPerGame": 1.2,
      "stealsPerGame": 0.6,
      "blocksPerGame": 0.5,
      "fieldGoalPercentage": 42.1,
      "threePointPercentage": 26.2,
      "freeThrowPercentage": 78.9
    },
    "transferHistory": [
      {
        "recordId": "3336",
        "previousSchool": "NJIT",
        "destination": "St. Bonaventure",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46128609",
    "name": "Aric Demings",
    "sport": "basketball",
    "position": "PG",
    "previousSchool": "West Florida",
    "destination": "Eastern Kentucky",
    "season": 2026,
    "profileUrl": "basketball-profile-46128609.html",
    "stats": {},
    "transferHistory": [
      {
        "recordId": "288122",
        "previousSchool": "West Florida",
        "destination": "Eastern Kentucky",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46128288",
    "name": "Armani Mighty",
    "sport": "basketball",
    "position": "C",
    "previousSchool": "Mercer",
    "destination": "Pittsburgh",
    "season": 2026,
    "profileUrl": "basketball-profile-46128288.html",
    "stats": {
      "minutesPerGame": 31.1,
      "pointsPerGame": 13.2,
      "reboundsPerGame": 10.6,
      "assistsPerGame": 1.1,
      "stealsPerGame": 0.7,
      "blocksPerGame": 1.7,
      "fieldGoalPercentage": 64.5,
      "threePointPercentage": 0.0,
      "freeThrowPercentage": 53.9
    },
    "transferHistory": [
      {
        "recordId": "91377",
        "previousSchool": "Mercer",
        "destination": "Pittsburgh",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46128576",
    "name": "Armoni Zeigler",
    "sport": "basketball",
    "position": "SG",
    "previousSchool": "Ball State",
    "destination": "Boston College",
    "season": 2026,
    "profileUrl": "basketball-profile-46128576.html",
    "stats": {
      "minutesPerGame": 32.4,
      "pointsPerGame": 12.5,
      "reboundsPerGame": 5.1,
      "assistsPerGame": 3.3,
      "stealsPerGame": 1.4,
      "blocksPerGame": 0.3,
      "fieldGoalPercentage": 40.2,
      "threePointPercentage": 33.0,
      "freeThrowPercentage": 77.9
    },
    "transferHistory": [
      {
        "recordId": "541216",
        "previousSchool": "Ball State",
        "destination": "Boston College",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46115035",
    "name": "Arop Arop",
    "sport": "basketball",
    "position": "SF",
    "previousSchool": "Memphis",
    "destination": "Nicholls",
    "season": 2026,
    "profileUrl": "basketball-profile-46115035.html",
    "stats": {
      "minutesPerGame": 2.6,
      "pointsPerGame": 0.7,
      "reboundsPerGame": 0.7,
      "assistsPerGame": 0.0,
      "stealsPerGame": 0.0,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 33.3,
      "threePointPercentage": 0.0,
      "freeThrowPercentage": 50.0
    },
    "transferHistory": [
      {
        "recordId": "105628",
        "previousSchool": "Memphis",
        "destination": "Nicholls",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46132338",
    "name": "Arrinten Page",
    "sport": "basketball",
    "position": "C",
    "previousSchool": "Northwestern",
    "destination": "Providence",
    "season": 2026,
    "profileUrl": "basketball-profile-46132338.html",
    "stats": {
      "minutesPerGame": 22.8,
      "pointsPerGame": 10.2,
      "reboundsPerGame": 4.5,
      "assistsPerGame": 1.8,
      "stealsPerGame": 0.9,
      "blocksPerGame": 1.2,
      "fieldGoalPercentage": 54.6,
      "threePointPercentage": 25.0,
      "freeThrowPercentage": 65.6
    },
    "transferHistory": [
      {
        "recordId": "2982",
        "previousSchool": "Northwestern",
        "destination": "Providence",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46094923",
    "name": "Arterio Morris",
    "sport": "basketball",
    "position": "CG",
    "previousSchool": "Bethune-Cookman",
    "destination": "Tennessee State",
    "season": 2026,
    "profileUrl": "basketball-profile-46094923.html",
    "stats": {
      "minutesPerGame": 27.7,
      "pointsPerGame": 11.5,
      "reboundsPerGame": 3.8,
      "assistsPerGame": 2.9,
      "stealsPerGame": 1.5,
      "blocksPerGame": 0.9,
      "fieldGoalPercentage": 41.2,
      "threePointPercentage": 24.7,
      "freeThrowPercentage": 56.6
    },
    "transferHistory": [
      {
        "recordId": "2994",
        "previousSchool": "Bethune-Cookman",
        "destination": "Tennessee State",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46077115",
    "name": "Arturo Dean",
    "sport": "basketball",
    "position": "PG",
    "previousSchool": "Oklahoma State",
    "destination": "UCF",
    "season": 2026,
    "profileUrl": "basketball-profile-46077115.html",
    "stats": {
      "minutesPerGame": 24.3,
      "pointsPerGame": 7.6,
      "reboundsPerGame": 3.1,
      "assistsPerGame": 3.4,
      "stealsPerGame": 2.5,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 39.6,
      "threePointPercentage": 27.5,
      "freeThrowPercentage": 68.8
    },
    "transferHistory": [
      {
        "recordId": "27518",
        "previousSchool": "Oklahoma State",
        "destination": "UCF",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46115306",
    "name": "Asa Thomas",
    "sport": "basketball",
    "position": "SF",
    "previousSchool": "Furman",
    "destination": "Chicago",
    "season": 2026,
    "profileUrl": "basketball-profile-46115306.html",
    "stats": {
      "minutesPerGame": 27.4,
      "pointsPerGame": 11.9,
      "reboundsPerGame": 3.8,
      "assistsPerGame": 1.9,
      "stealsPerGame": 0.4,
      "blocksPerGame": 0.4,
      "fieldGoalPercentage": 40.7,
      "threePointPercentage": 38.2,
      "freeThrowPercentage": 74.0
    },
    "transferHistory": [
      {
        "recordId": "3033",
        "previousSchool": "Furman",
        "destination": "Chicago",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166299",
    "name": "Ashley Sims II",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Bryant",
    "destination": "SE Louisiana",
    "season": 2026,
    "profileUrl": "basketball-profile-46166299.html",
    "stats": {
      "minutesPerGame": 31.4,
      "pointsPerGame": 7.2,
      "reboundsPerGame": 5.0,
      "assistsPerGame": 2.0,
      "stealsPerGame": 0.7,
      "blocksPerGame": 0.4,
      "fieldGoalPercentage": 48.7,
      "threePointPercentage": 17.9,
      "freeThrowPercentage": 48.9
    },
    "transferHistory": [
      {
        "recordId": "80810",
        "previousSchool": "Bryant",
        "destination": "SE Louisiana",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46117948",
    "name": "Ashton Hardaway",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Memphis",
    "destination": "Coastal Carolina",
    "season": 2026,
    "profileUrl": "basketball-profile-46117948.html",
    "stats": {
      "minutesPerGame": 19.5,
      "pointsPerGame": 5.6,
      "reboundsPerGame": 2.5,
      "assistsPerGame": 1.4,
      "stealsPerGame": 0.8,
      "blocksPerGame": 0.7,
      "fieldGoalPercentage": 39.8,
      "threePointPercentage": 34.3,
      "freeThrowPercentage": 73.7
    },
    "transferHistory": [
      {
        "recordId": "2842",
        "previousSchool": "Memphis",
        "destination": "Coastal Carolina",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46118692",
    "name": "Ashton Magee",
    "sport": "basketball",
    "position": "SF",
    "previousSchool": "Southern",
    "destination": "Mississippi State",
    "season": 2026,
    "profileUrl": "basketball-profile-46118692.html",
    "stats": {
      "minutesPerGame": 11.3,
      "pointsPerGame": 3.0,
      "reboundsPerGame": 1.7,
      "assistsPerGame": 0.2,
      "stealsPerGame": 0.3,
      "blocksPerGame": 0.3,
      "fieldGoalPercentage": 44.4,
      "threePointPercentage": 20.0,
      "freeThrowPercentage": 64.3
    },
    "transferHistory": [
      {
        "recordId": "1206142",
        "previousSchool": "Southern",
        "destination": "Mississippi State",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46131196",
    "name": "Ashton Simmons",
    "sport": "basketball",
    "position": "PG",
    "previousSchool": "TCU",
    "destination": "Stephen F. Austin",
    "season": 2026,
    "profileUrl": "basketball-profile-46131196.html",
    "stats": {
      "minutesPerGame": 3.8,
      "pointsPerGame": 1.0,
      "reboundsPerGame": 0.6,
      "assistsPerGame": 0.2,
      "stealsPerGame": 0.0,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 28.6,
      "threePointPercentage": 25.0,
      "freeThrowPercentage": 0.0
    },
    "transferHistory": [
      {
        "recordId": "2863",
        "previousSchool": "TCU",
        "destination": "Stephen F. Austin",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46101516",
    "name": "Ashton Smith",
    "sport": "basketball",
    "position": "C",
    "previousSchool": "South Dakota",
    "destination": "UTSA",
    "season": 2026,
    "profileUrl": "basketball-profile-46101516.html",
    "stats": {
      "minutesPerGame": 4.5,
      "pointsPerGame": 0.5,
      "reboundsPerGame": 0.7,
      "assistsPerGame": 0.0,
      "stealsPerGame": 0.2,
      "blocksPerGame": 0.2,
      "fieldGoalPercentage": 25.0,
      "threePointPercentage": 0.0,
      "freeThrowPercentage": 50.0
    },
    "transferHistory": [
      {
        "recordId": "4530375",
        "previousSchool": "South Dakota",
        "destination": "UTSA",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46149895",
    "name": "Ashton Walker",
    "sport": "basketball",
    "position": "PG",
    "previousSchool": "La Salle",
    "destination": "Monmouth",
    "season": 2026,
    "profileUrl": "basketball-profile-46149895.html",
    "stats": {
      "minutesPerGame": 27.5,
      "pointsPerGame": 8.2,
      "reboundsPerGame": 3.8,
      "assistsPerGame": 3.1,
      "stealsPerGame": 1.1,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 39.3,
      "threePointPercentage": 31.6,
      "freeThrowPercentage": 65.3
    },
    "transferHistory": [
      {
        "recordId": "3445",
        "previousSchool": "La Salle",
        "destination": "Monmouth",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46114394",
    "name": "Ashton Williamson",
    "sport": "basketball",
    "position": "CG",
    "previousSchool": "Florida International",
    "destination": "Purdue Fort Wayne",
    "season": 2026,
    "profileUrl": "basketball-profile-46114394.html",
    "stats": {
      "minutesPerGame": 22.6,
      "pointsPerGame": 7.7,
      "reboundsPerGame": 2.5,
      "assistsPerGame": 2.6,
      "stealsPerGame": 1.1,
      "blocksPerGame": 0.1,
      "fieldGoalPercentage": 38.2,
      "threePointPercentage": 31.6,
      "freeThrowPercentage": 81.8
    },
    "transferHistory": [
      {
        "recordId": "2827",
        "previousSchool": "Florida International",
        "destination": "Purdue Fort Wayne",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46110370",
    "name": "Assane Diop",
    "sport": "basketball",
    "position": "C",
    "previousSchool": "San Diego",
    "destination": "Kansas City",
    "season": 2026,
    "profileUrl": "basketball-profile-46110370.html",
    "stats": {
      "minutesPerGame": 18.8,
      "pointsPerGame": 5.7,
      "reboundsPerGame": 5.2,
      "assistsPerGame": 1.3,
      "stealsPerGame": 0.3,
      "blocksPerGame": 0.4,
      "fieldGoalPercentage": 49.6,
      "threePointPercentage": 41.9,
      "freeThrowPercentage": 59.3
    },
    "transferHistory": [
      {
        "recordId": "2539",
        "previousSchool": "San Diego",
        "destination": "Kansas City",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46157166",
    "name": "Augustinas Kiudulas",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Colorado State",
    "destination": "Western Michigan",
    "season": 2026,
    "profileUrl": "basketball-profile-46157166.html",
    "stats": {
      "minutesPerGame": 14.6,
      "pointsPerGame": 5.9,
      "reboundsPerGame": 2.7,
      "assistsPerGame": 0.8,
      "stealsPerGame": 0.5,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 53.4,
      "threePointPercentage": 41.2,
      "freeThrowPercentage": 69.0
    },
    "transferHistory": [
      {
        "recordId": "2635",
        "previousSchool": "Colorado State",
        "destination": "Western Michigan",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46153094",
    "name": "Augusto Cassia",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Ole Miss",
    "destination": "UTEP",
    "season": 2026,
    "profileUrl": "basketball-profile-46153094.html",
    "stats": {
      "minutesPerGame": 10.4,
      "pointsPerGame": 2.2,
      "reboundsPerGame": 1.6,
      "assistsPerGame": 0.5,
      "stealsPerGame": 0.4,
      "blocksPerGame": 0.2,
      "fieldGoalPercentage": 45.5,
      "threePointPercentage": 25.0,
      "freeThrowPercentage": 77.8
    },
    "transferHistory": [
      {
        "recordId": "2680",
        "previousSchool": "Ole Miss",
        "destination": "UTEP",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46125736",
    "name": "Austin Maurer",
    "sport": "basketball",
    "position": "C",
    "previousSchool": "Seattle U",
    "destination": "Stanford",
    "season": 2026,
    "profileUrl": "basketball-profile-46125736.html",
    "stats": {
      "minutesPerGame": 17.9,
      "pointsPerGame": 7.2,
      "reboundsPerGame": 4.7,
      "assistsPerGame": 0.5,
      "stealsPerGame": 0.6,
      "blocksPerGame": 0.9,
      "fieldGoalPercentage": 52.2,
      "threePointPercentage": 25.6,
      "freeThrowPercentage": 72.4
    },
    "transferHistory": [
      {
        "recordId": "2973",
        "previousSchool": "Seattle U",
        "destination": "Stanford",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46141711",
    "name": "Austin Montgomery",
    "sport": "basketball",
    "position": "SF",
    "previousSchool": "Georgetown",
    "destination": "",
    "season": 2026,
    "profileUrl": "basketball-profile-46141711.html",
    "stats": {
      "minutesPerGame": 2.0,
      "pointsPerGame": 0.0,
      "reboundsPerGame": 0.0,
      "assistsPerGame": 0.0,
      "stealsPerGame": 0.0,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 0.0,
      "threePointPercentage": 0.0,
      "freeThrowPercentage": 0.0
    },
    "transferHistory": [
      {
        "recordId": "2425",
        "previousSchool": "Georgetown",
        "destination": "",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46098087",
    "name": "Austin Nunez",
    "sport": "basketball",
    "position": "PG",
    "previousSchool": "UTSA",
    "destination": "LSU",
    "season": 2026,
    "profileUrl": "basketball-profile-46098087.html",
    "stats": {
      "minutesPerGame": 28.5,
      "pointsPerGame": 9.8,
      "reboundsPerGame": 2.1,
      "assistsPerGame": 2.8,
      "stealsPerGame": 1.1,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 30.4,
      "threePointPercentage": 25.3,
      "freeThrowPercentage": 88.5
    },
    "transferHistory": [
      {
        "recordId": "3040",
        "previousSchool": "UTSA",
        "destination": "LSU",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46098106",
    "name": "Avery Brown",
    "sport": "basketball",
    "position": "PG",
    "previousSchool": "Columbia",
    "destination": "St. John's",
    "season": 2026,
    "profileUrl": "basketball-profile-46098106.html",
    "stats": {
      "minutesPerGame": 15.0,
      "pointsPerGame": 4.3,
      "reboundsPerGame": 2.0,
      "assistsPerGame": 0.3,
      "stealsPerGame": 0.0,
      "blocksPerGame": 0.0,
      "fieldGoalPercentage": 36.4,
      "threePointPercentage": 75.0,
      "freeThrowPercentage": 50.0
    },
    "transferHistory": [
      {
        "recordId": "3478",
        "previousSchool": "Columbia",
        "destination": "St. John's",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46166135",
    "name": "Avery Thomas II",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Louisiana Tech",
    "destination": "Kennesaw State",
    "season": 2026,
    "profileUrl": "basketball-profile-46166135.html",
    "stats": {
      "minutesPerGame": 25.2,
      "pointsPerGame": 9.1,
      "reboundsPerGame": 7.2,
      "assistsPerGame": 0.6,
      "stealsPerGame": 1.2,
      "blocksPerGame": 0.5,
      "fieldGoalPercentage": 40.3,
      "threePointPercentage": 30.0,
      "freeThrowPercentage": 77.8
    },
    "transferHistory": [
      {
        "recordId": "2641",
        "previousSchool": "Louisiana Tech",
        "destination": "Kennesaw State",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46118012",
    "name": "Ayden Evans",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Ohio",
    "destination": "Maine",
    "season": 2026,
    "profileUrl": "basketball-profile-46118012.html",
    "stats": {
      "minutesPerGame": 8.2,
      "pointsPerGame": 2.3,
      "reboundsPerGame": 1.1,
      "assistsPerGame": 0.3,
      "stealsPerGame": 0.3,
      "blocksPerGame": 0.5,
      "fieldGoalPercentage": 45.5,
      "threePointPercentage": 16.7,
      "freeThrowPercentage": 66.7
    },
    "transferHistory": [
      {
        "recordId": "3384",
        "previousSchool": "Ohio",
        "destination": "Maine",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46157211",
    "name": "Ayomide Bamisile",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "UL Monroe",
    "destination": "Little Rock",
    "season": 2026,
    "profileUrl": "basketball-profile-46157211.html",
    "stats": {
      "minutesPerGame": 13.8,
      "pointsPerGame": 2.8,
      "reboundsPerGame": 3.0,
      "assistsPerGame": 0.2,
      "stealsPerGame": 0.5,
      "blocksPerGame": 0.8,
      "fieldGoalPercentage": 50.9,
      "threePointPercentage": 0.0,
      "freeThrowPercentage": 50.0
    },
    "transferHistory": [
      {
        "recordId": "1359164",
        "previousSchool": "UL Monroe",
        "destination": "Little Rock",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46163346",
    "name": "Ayuba Bryant Jr.",
    "sport": "basketball",
    "position": "PF",
    "previousSchool": "Temple",
    "destination": "North Florida",
    "season": 2026,
    "profileUrl": "basketball-profile-46163346.html",
    "stats": {
      "minutesPerGame": 8.1,
      "pointsPerGame": 1.8,
      "reboundsPerGame": 1.6,
      "assistsPerGame": 0.1,
      "stealsPerGame": 0.3,
      "blocksPerGame": 0.3,
      "fieldGoalPercentage": 58.6,
      "threePointPercentage": 0.0,
      "freeThrowPercentage": 45.2
    },
    "transferHistory": [
      {
        "recordId": "131126",
        "previousSchool": "Temple",
        "destination": "North Florida",
        "season": "2026"
      }
    ],
    "needsReview": false
  },
  {
    "playerId": "46142011",
    "name": "Azavier Robinson",
    "sport": "basketball",
    "position": "PG",
    "previousSchool": "Butler",
    "destination": "UCLA",
    "season": 2026,
    "profileUrl": "basketball-profile-46142011.html",
    "stats": {
      "minutesPerGame": 18.3,
      "pointsPerGame": 6.1,
      "reboundsPerGame": 1.9,
      "assistsPerGame": 2.5,
      "stealsPerGame": 1.5,
      "blocksPerGame": 0.3,
      "fieldGoalPercentage": 47.0,
      "threePointPercentage": 43.3,
      "freeThrowPercentage": 71.1
    },
    "transferHistory": [
      {
        "recordId": "3216",
        "previousSchool": "Butler",
        "destination": "UCLA",
        "season": "2026"
      }
    ],
    "needsReview": false
  }
];
